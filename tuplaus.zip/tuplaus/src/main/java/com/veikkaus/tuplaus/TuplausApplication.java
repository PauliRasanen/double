package com.veikkaus.tuplaus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TuplausApplication {

	public static void main(String[] args) {
		SpringApplication.run(TuplausApplication.class, args);
	}

}
