package com.veikkaus.tuplaus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuplausApplicationTests {

	@Test
	void contextLoads() {
	}

}
